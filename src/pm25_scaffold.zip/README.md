# Ontario PM2.5 preprocessing scaffold

## Install (editable)
```bash
python -m pip install -e .
```

## Build hourly cleaned dataset
```bash
python scripts/build_hourly_pm25.py --out outputs/pm25_hourly_cleaned.parquet --report-out outputs/dedupe_report.json
```

## Build daily dataset
```bash
python scripts/build_daily_pm25.py --hourly outputs/pm25_hourly_cleaned.parquet --out outputs/pm25_daily_cleaned.csv --min-hours 15
```
