# 01 Missingness

- Build balanced panel (`pm25.panel.make_balanced_panel`)
- Missing-by-column table
- Missing-by-station table
- All-day-missing over time plot
