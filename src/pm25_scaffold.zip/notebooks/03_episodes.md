# 03 Episode timeline

- Define event day (threshold + min hours)
- Build episode summary
- Plot broken-bar timeline
