# 02 Target analysis

- Distribution of Ontario daily mean
- Monthly trend + seasonality
- Hour-of-day mean curve
- Mean by station + map (geopandas)
